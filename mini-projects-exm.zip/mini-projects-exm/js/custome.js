$(document).ready(function(){
$('body').click(function(e){	
	if(!$(e.target).closest(".site-nav").length){
		if($(e.target).closest(".responsive-menu-toggle-icon").length){
			$(".site-nav").slideToggle("slow");	
		}else{
			$(".site-nav").slideUp();	
		}
	}
});
	/*$(".responsive-menu-toggle-icon").click(function(){
		$(".site-nav").slideToggle("slow");		
	});*/
	$(".parent-list").click(function(){
		$(this).parent().siblings().removeClass("expanded");
		$(this).parent().toggleClass("expanded");
		

	});
	
	
	
});
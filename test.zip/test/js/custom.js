/*tab menu bar start here*/
$( document ).ready(function() {
	$('.tab-btn li').click(function() {
		$('.tab-content > li:eq(' + $(this).index() + ')').show();
		$('.tab-content > li:not(:eq(' + $(this).index() + '))').hide();
		
		$('.tab-content > li:eq(' + $(this).index() + ')').addClass('current');
		$('.tab-content > li:not(:eq(' + $(this).index() + '))').removeClass('current');
		
		$('.tab-btn li').removeClass('current');
		$(this).addClass('current');
	});
	
	// add active class
	$(".tab-btn > li").click(function(){
		$(".tab-btn > li").removeClass("active");
		$(this).addClass("active");
		});
/*tab menu bar close here*/

       //Navigation Menu Slider
        $('#nav-expander').on('click',function(e){
      		e.preventDefault();
      		$('body').toggleClass('nav-expanded');
      	});
      	$('#nav-close').on('click',function(e){
      		e.preventDefault();
      		$('body').removeClass('nav-expanded');
      	});
		// add active class
		$(".main-menu  li").click(function(){
			$(".main-menu  li").removeClass("active");
			$(this).addClass("active");
			});
	
	
});


( function( $ ) {
$( document ).ready(function() {
$('.main-menu li.has-sub>a').on('click', function(){
		$(this).removeAttr('href');
		var element = $(this).parent('li');
		if (element.hasClass('open')) {
			element.removeClass('open');
			element.find('li').removeClass('open');
			element.find('ul').slideUp();
		}
		else {
			element.addClass('open');
			element.children('ul').slideDown();
			element.siblings('li').children('ul').slideUp();
			element.siblings('li').removeClass('open');
			element.siblings('li').find('li').removeClass('open');
			element.siblings('li').find('ul').slideUp();
		}
	});

	$('.main-menu>ul>li.has-sub>a').append('<span class="holder"></span>');


});
} )( jQuery );


var app = angular.module('myApp', []);
app.controller('myCtrl', function($scope){
	
	$scope.collage = [{
		"name":"menu1",
		"name":"menu2",
		"name":"menu3",
		"name":"menu4",
		
	}];
	$scope.collage1 = [{
		"name":"item1",
		"name":"item2",
		"name":"item3",
		"name":"item4",
		
	}];
	$scope.collage2 = [{
		"name":"list1",
		"name":"list2",
		"name":"list3",
		"name":"list4",
		
	}];
	
	
	/*
	$scope.MenuItem1 = false;
	$scope.item1 = function(){
		$scope.MenuItem1 = !$scope.MenuItem1;
	}
	$scope.MenuItem2 = false;
	$scope.item2 = function(){
		$scope.MenuItem2 = !$scope.MenuItem2;
	}
	$scope.MenuItem3 = false;
	$scope.item3 = function(){
		$scope.MenuItem3 = !$scope.MenuItem3;
	}
	*/
});


